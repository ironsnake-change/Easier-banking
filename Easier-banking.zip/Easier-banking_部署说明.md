# Easier-banking 部署说明

## 1. 部署形态

项目提供三种运行方式：

1. Windows 单文件 EXE：双击即用，不需要 Python 环境。
2. Python 源码运行：适合开发、答辩复现和服务器部署。
3. 反向代理部署：由 Nginx、云托管平台或企业网关终止 TLS，再将请求转发到 FastAPI。

SQLite 只能支撑单机演示。生产环境应把账务、提案、会话和审计数据迁移到具备事务隔离与备份能力的数据库。

## 2. Windows 桌面版

直接分发 `Easier-banking_桌面版.exe` 和 `SHA256` 文件。

运行步骤：

1. 双击 EXE。
2. 应用选择随机本机端口启动 FastAPI，只监听 `127.0.0.1`。
3. 应用使用 Edge/Chrome 的独立窗口打开工作台。
4. 关闭浏览器窗口后，后台服务退出。

运行数据：

```text
%LOCALAPPDATA%\Easier-banking\bank_core.db
%LOCALAPPDATA%\Easier-banking\desktop.log
%LOCALAPPDATA%\Easier-banking\browser-profile\
```

如果要重置桌面数据，关闭应用后删除 `bank_core.db`，下次启动会重新种子化。

## 3. Python 源码部署

要求 Python 3.11+。

```powershell
cd Easier-banking
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

验证：

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/health
```

期望响应包含：

```json
{
  "status": "ok",
  "demo_mode": true,
  "gateway_mode": "cloud"
}
```

如果 `gateway_mode` 是 `offline`，说明网关变量为空、为 `YOUR_` 占位值或当前部署明确选择了离线模式。离线模式仍可登录、查询和使用本地规则引擎办理受控业务。

## 4. 环境文件

复制 `.env.example` 为 `.env`。进程环境变量优先于 `.env`。

```dotenv
DEMO_MODE=1
EASIER_BANKING_CLOUD_RATE_LIMIT=20
EASIER_BANKING_CLOUD_TIMEOUT_SECONDS=8
EASIER_BANKING_CLOUD_FAILURE_THRESHOLD=3
EASIER_BANKING_CLOUD_CIRCUIT_SECONDS=60
EASIER_BANKING_SESSION_TTL_SECONDS=28800
EASIER_BANKING_LOGIN_MAX_FAILURES=5
EASIER_BANKING_LOGIN_FAILURE_WINDOW_SECONDS=300
EASIER_BANKING_LOGIN_LOCK_SECONDS=300
```

部署到公网时：

- 将 `DEMO_MODE` 设为 `0`。
- 设置固定的 `OTP_PEPPER`，不要使用进程级随机值。
- 通过密钥管理系统注入网关凭证，`OTP_PEPPER` 和网关密钥不得进入日志或 Git。
- 如果多进程运行，`OTP_PEPPER` 必须在所有实例间一致，提案与 OTP 会话需要使用共享数据库。

## 5. 云端模型排查

云端异常的排查顺序：

1. 访问 `/api/health`，确认 `gateway_mode=cloud`。
2. 登录后访问 `/api/assistant/probe`，确认返回 `status=ONLINE`。该接口需要 `X-Session-Token`。
3. 查看浏览器网络面板，确认请求发往本机 `/api/assistant/chat`，而不是直接发往模型域名。
4. 查看服务端日志中的 `Cloud reply failed` 或 `Gateway probe failed`。
5. 检查是否达到每用户 20 次/分钟限流，或连续 3 次失败触发 60 秒熔断。
6. 确认不是直接双击 `static/index.html`。这种方式没有后端，不会使用云端模型。
7. 使用强制刷新或无痕窗口，排除旧版 `app.js` 缓存。当前版本已经给静态资源加版本号并返回 `no-store`。
8. 如果桌面端顶栏显示“模式：离线”，进入“系统与偏好设置”，点击“立即探测网关”。新版本会清除残留的本地模式并重新切换到云端。

桌面 EXE 的 TLS 故障日志位于 `%LOCALAPPDATA%\Easier-banking\desktop.log`。打包配置已显式包含运行环境所需的拒绝证书清单和 CA bundle。

## 6. 可选反向代理

FastAPI 默认只监听回环地址。若部署到服务器，可以让反向代理监听公网，将流量转发到 `127.0.0.1:8000`，并在代理层启用 HTTPS、请求体上限和访问日志脱敏。

不要开放 `/api/system/reset-demo` 或 `/api/security/reset-breaker` 到非演示环境；应用会在 `DEMO_MODE=0` 时返回 403。

## 7. 重建桌面应用

在 Windows 且已安装 Python 3.11+：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File build_desktop.ps1
```

首次构建会创建 `.desktop_venv` 并安装 PyInstaller。产物位于 `dist/Easier-banking.exe`，构建脚本会输出 SHA-256。

## 8. 上线检查清单

- `DEMO_MODE=0`
- 固定且随机长度足够的 `OTP_PEPPER`
- 网关地址和密钥来自密钥管理，不写入源码
- 使用 HTTPS
- 反向代理限制请求体和连接数
- 替换演示账号与演示数据
- 接入 KYC、AML、人脸或安全密钥
- 启用数据库备份、审计归档和告警
- 对 EXE 做企业代码签名
