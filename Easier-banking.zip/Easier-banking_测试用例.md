# Easier-banking 测试用例

## 1. 执行方式

```powershell
cd Easier-banking
python -m pytest -q
```

最近一次完整执行结果：`90 passed`。测试默认使用临时 SQLite 文件，不污染正式演示数据库。

## 2. 自动化测试覆盖

| 编号 | 场景 | 测试位置 | 预期 |
|---|---|---|---|
| TC-01 | 旧 `/action`、`/execute` 携带 `confirmed=true` | `tests/test_confirm_gate.py::test_deprecated_execution_endpoints_reject_client_confirmation` | HTTP 410；余额不变；提案数不增加 |
| TC-02 | 同一提案并发确认 | `tests/test_confirm_gate.py::test_concurrent_confirm_executes_exactly_once` | 一个 200、一个 409；只扣款一次 |
| TC-03 | 他人提案、错误 token、参数篡改、过期 | `tests/test_confirm_gate.py::test_owner_token_params_and_expiry_are_enforced` | 分别返回 403/403/409/409，均不执行 |
| TC-04 | L3 OTP 必填和三次失败作废 | `tests/test_confirm_gate.py::test_l3_otp_is_server_issued_counted_and_required` | 缺失 428；错误计数；三次后作废；新提案验证成功 |
| TC-05 | `DEMO_MODE=0` 不返回明文 OTP | `tests/test_confirm_gate.py::test_l3_demo_hint_is_absent_when_demo_mode_is_disabled`、`tests/test_hardening_evidence.py::test_otp_has_no_plaintext_in_production_response` | `demo_hint` 为 null；响应无 OTP 字段 |
| TC-06 | 临时额度到期恢复 | `tests/test_confirm_gate.py::test_temporary_limit_override_expires_without_mutating_base_limit` | 临时额度生效后过期；`transfer_threshold` 不变 |
| TC-07 | 五类提案审计事件 | `tests/test_hardening_evidence.py::test_all_proposal_transition_event_types_are_audited` | CREATED/CONFIRMED/CANCELLED/EXPIRED/EXECUTED 均存在 |
| TC-08 | 订阅接口与 DAG 均调用风险策略 | `tests/test_hardening_evidence.py::test_subscription_endpoint_and_dag_registry_both_call_policy_classify` | spy 捕获 `policy.classify` 调用 |
| TC-09 | 身份声明不越权 | `tests/test_intent_fix.py::test_identity_claim_does_not_change_permissions` | 明确说明身份不改变权限；不生成无收款人转账 |
| TC-10 | 32 条只读口语不触发写操作 | `tests/test_intent_fix.py::test_read_only_language_never_triggers_write_action` | 全部返回 None 动作 |
| TC-11 | 中文金额 | `tests/test_intent_fix.py::test_chinese_amount_parser_and_transfer_slots` | 二百/两千/一万二/2k 正确解析 |
| TC-12 | 卡尾号精确匹配 | `tests/test_intent_fix.py::test_card_tail_targets_exact_card_and_never_falls_back` | 4806 冻结，8848 不受影响 |
| TC-13 | 未知订阅不伪造 | `tests/test_intent_fix.py::test_unknown_subscription_is_not_inserted_or_claimed` | 返回“未找到”；订阅总数不变 |
| TC-14 | 提案追溯使用真实耗时 | `tests/test_hardening_evidence.py::test_receipt_trace_uses_measured_executor_facts` | 无伪 DAG 声明；事务耗时来自实测 |
| TC-15 | 重置权限与审计保留 | `tests/test_hardening_evidence.py::test_demo_mode_reset_endpoints_are_forbidden_outside_demo`、`test_reset_demo_preserves_audit_chain` | 非演示返回 403；重置后审计链完整 |
| TC-16 | 会话过期与登录锁定 | `tests/test_hardening_evidence.py::test_session_expiry_column_and_default_ttl`、`test_login_is_locked_after_five_failures_for_same_identity`、`test_login_ip_bucket_locks_across_distinct_unknown_usernames` | 8 小时过期；五次失败锁定；返回 Retry-After |
| TC-17 | 空白网关凭证离线 | `tests/test_hardening_evidence.py::test_empty_gateway_secret_never_calls_network` | 不发起网络请求；health 为 offline；聊天使用本地规则 |
| TC-18 | 网关限流、超时与熔断 | `tests/test_hardening_evidence.py::test_cloud_timeout_rate_limit_and_circuit_breaker` | 每分钟上限、8 秒超时、三次失败熔断 |
| TC-19 | 模型上下文隐私 | `tests/test_hardening_evidence.py::test_cloud_payload_is_minimized_to_card_tail_only` | 无手机号、证件号、完整卡号；只保留尾号 |
| TC-20 | 静态前端离线下拒绝写操作 | `tests/test_hardening_evidence.py::test_static_offline_mode_never_executes_actions` | 本地授权和资金执行函数无法执行 |
| TC-21 | 敏感字符串与凭证扫描 | `tests/test_hardening_evidence.py::test_core_and_static_do_not_embed_legacy_persona_salutations`、`test_gateway_secret_is_single_sourced_and_no_legacy_pin_exists` | 旧称呼无命中；密钥只在 config 一处 |
| TC-22 | 桌面启动器模式 | `tests/test_hardening_evidence.py::test_application_starts_in_both_demo_modes`、`test_startup_log_reports_demo_and_gateway_mode` | DEMO_MODE=0/1 均可启动；日志显示模式 |

## 3. 手工验收流程

### 3.1 登录与会话

1. 以 `linyan / Demo@2026` 登录。
2. 确认页面显示“KYC 已核验”、云端/离线模式和 8 小时会话策略。
3. 连续输入错误密码 5 次，确认用户名或 IP 被锁定 5 分钟。

### 3.2 只读查询

发送：

```text
查询账户余额
帮我看一下我的订阅情况
最近有哪些异常交易？
```

预期：不生成授权提案；余额、订阅和异常交易由真实 SQLite 数据返回。

### 3.3 黄色确认转账

1. 以林砚登录。
2. 发送“给房东陈姐转 200 元”。
3. 确认出现 L2 确认卡，账户余额在确认前不变。
4. 点击确认，页面余额减少 200 元；刷新后只出现一条转账流水。
5. 再次尝试点击旧提案确认，预期返回冲突，不重复扣款。

### 3.4 L3 强验证

1. 发送一笔超过今日剩余额度或向未登记收款人的转账。
2. 确认出现 L3 卡片。
3. `DEMO_MODE=1` 时，从提示读取 6 位一次性验证码。
4. 先输入错误验证码两次，确认剩余次数减少。
5. 第三次错误后提案作废；重新发起提案并输入正确验证码完成。

### 3.5 订阅撤销

1. 发送“退订流媒体”。
2. 确认后，订阅状态变为 CANCELLED。
3. 发送“撤回”。
4. 预期生成 `restore_subscription` 提案，不直接恢复；再次确认后状态回 ACTIVE。

### 3.6 桌面版

1. 双击 `Easier-banking_桌面版.exe`。
2. 确认自动打开 Edge/Chrome 应用窗口。
3. 登录并发送只读查询。
4. 检查 `%LOCALAPPDATA%\Easier-banking\desktop.log` 无 TLS/导入错误。
5. 启动器自检使用：

```powershell
$env:EASIER_BANKING_SMOKE_TEST='1'
$env:EASIER_BANKING_SMOKE_RESULT="$env:TEMP\easier-smoke.json"
Start-Process .\Easier-banking_桌面版.exe -Wait
Get-Content $env:EASIER_BANKING_SMOKE_RESULT
```

预期 `probe.status=ONLINE`。如果返回 `OFFLINE`，查看 `gateway_mode` 和 `desktop.log`。

## 4. 回归门禁

提交前必须满足：

- `pytest -q` 全部通过。
- Python AST 检查无语法错误。
- `static/app.js`、`static/tts-engine.js` 通过 Node 语法检查。
- `git grep -n "bank2026test"` 仅在 `core/config.py` 出现一次。
- `git grep -n "888888"` 无结果。
- `core/`、`static/` 不出现旧称呼“张叔叔 / 张建国 / 张大爷”。
- 桌面 EXE 自检返回 0，且 `probe.status=ONLINE`。
